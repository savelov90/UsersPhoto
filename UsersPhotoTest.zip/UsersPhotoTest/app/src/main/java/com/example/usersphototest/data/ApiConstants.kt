package com.example.usersphototest.data

object ApiConstants {

    const val USERS_URL = "https://jsonplaceholder.typicode.com/users"
    const val PHOTOS_URL = "https://jsonplaceholder.typicode.com/photos"

}