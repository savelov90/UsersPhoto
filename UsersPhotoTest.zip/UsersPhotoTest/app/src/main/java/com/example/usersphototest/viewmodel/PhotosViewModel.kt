package com.example.usersphototest.viewmodel

import androidx.lifecycle.ViewModel

class PhotosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}