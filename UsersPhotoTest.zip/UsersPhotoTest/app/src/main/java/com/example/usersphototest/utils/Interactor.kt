package com.example.usersphototest.utils

class Interactor() {

    fun getUsersFromApi() {
    }

}